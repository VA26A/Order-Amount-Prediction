import React from 'react';
import './table.css';

const Table = () => {
  
  return (
    <div className="grid_container">
      <form>
      <table className="gridtable">
        <thead>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">SI No</td>
            <td>CUSTOMER ORDER ID</td>
            <td>SALES ORG</td>
            <td>DISTRIBTUION CHANNEL</td>
            <td>COMPANY CODE</td>
            <td>ORDER CREATION DATE</td>
            <td>ORDER AMOUNT</td>
            <td>ORDER CURRENCY</td>
            <td>CUSTOMER NUMBER</td>
            <td>AMOUNT IN USD</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">1</td>
            <td>754349803</td>
            <td>3911</td>
            <td>United Arab Emirates</td>
            <td>3290</td>
            <td>01-01-2022</td>
            <td>1405.54</td>
            <td>AED</td>
            <td>1210499770</td>
            <td>382.67</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">2</td>
            <td>9302553442</td>
            <td>2381</td>
            <td>Greece</td>
            <td>3290</td>
            <td>01-01-2022</td>
            <td>1441.4835</td>
            <td>EUR</td>
            <td>1210351400</td>
            <td>1578.86</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">3</td>
            <td>819741436</td>
            <td>3605</td>
            <td>Argentina</td>
            <td>3290</td>
            <td>01-01-2022</td>
            <td>1065.33</td>
            <td>EUR</td>
            <td>121024309</td>
            <td>1166.86</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">4</td>
            <td>881355361</td>
            <td>3645</td>
            <td>Armenia</td>
            <td>3470</td>
            <td>02-01-2022</td>
            <td>302.85</td>
            <td>EUR</td>
            <td>12311152</td>
            <td>331.71</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">5</td>
            <td>821659852</td>
            <td>2470</td>
            <td>United States of America</td>
            <td>3220</td>
            <td>02-01-2022</td>
            <td>8380.69</td>
            <td>EUR</td>
            <td>1230021722</td>
            <td>9179.41</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">6</td>
            <td>957194828</td>
            <td>3150</td>
            <td>United States Minor Outlying Islands</td>
            <td>3290</td>
            <td>02-01-2022</td>
            <td>545.85</td>
            <td>EUR</td>
            <td>1210183107</td>
            <td>597.87</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">7</td>
            <td>806322513</td>
            <td>3396</td>
            <td>Serbia</td>
            <td>3290</td>
            <td>02-01-2022</td>
            <td>545.85</td>
            <td>AED</td> 
            <td>1210499770</td>
            <td>148.61</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="check"></input></td>
            <td class="adc">8</td>
            <td>922237131</td>
            <td>2353</td>
            <td>Turks and Caicos Islands</td>
            <td>3290</td>
            <td>02-01-2022</td>
            <td>562.73</td>
            <td>EUR</td>
            <td>1210111951</td>
            <td>616.3</td>
          </tr>
        </tbody>
      </table>
      </form>
    </div>
  );
};

export default Table;
