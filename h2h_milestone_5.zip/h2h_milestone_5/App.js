import logo from './logo.svg';
import './table.css';
import Table from './table';
import React from'react';
import table_data from './table.json';
import {useTable} from "react-table";


function App() {

  


  // const Table_as = ({ data }) => {
  //   const [selectedRows, setSelectedRows] = useState([]);
  
  //   const handleRowSelection = (row) => {
  //     setSelectedRows((prevSelectedRows) => {
  //       if (prevSelectedRows.includes(row)) {
  //         return prevSelectedRows.filter((r) => r !== row);
  //       } else {
  //         return [...prevSelectedRows, row];
  //       }
  //     });
  //   };

  // const data = React.useMemo(() => table_data, []);
  // const columns = React.useMemo(
  //   () => [
  //     {
  //       Header: '',
  //       accessor: 'checkbox',
  //       Cell: ({ row }) => (
  //         <input
  //           type="checkbox"
  //           checked={selectedRows.includes(row)}
  //           onChange={() => handleRowSelection(row)}
  //         />
  //       ),
  //     },
  //     {
  //       Header: "SL no",
  //       accessor: "sl_no",
  //     },
  //     {
  //       Header: "Customer Order ID",
  //       accessor: "Customer_Order_ID",
  //     },
  //     {
  //       Header: "Sales Org",
  //       accessor: "Sales_Org",
  //     },
  //     {
  //       Header: "DISTRIBUTION CHANNEL",
  //       accessor: "DISTRIBUTION_CHANNEL",
  //     },
  //     {
  //       Header: "Company Code",
  //       accessor: "Company_Code",
  //     },
  //     {
  //       Header: "Order Creation Date",
  //       accessor: "Order_creation_date",
  //     },
  //     {
  //       Header: "Order Amount",
  //       accessor: "Order_Amount",
  //     },
  //     {
  //       Header: "Order Currency",
  //       accessor: "Order_Currency",
  //     },
  //     {
  //       Header: "Customer Number",
  //       accessor: "Customer_Number",
  //     },
  //     {
  //       Header: "Amount in USD",
  //       accessor: "Amount_in_USD",
  //     },
  //   ],
  //   []
  // );
  // const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } =
  //   useTable({ columns, data });

  // return (
  //   <div className="App">
  //     <div className="container">
  //       <table {...getTableProps()}>
  //         <thead>
  //           {headerGroups.map((headerGroup) => (
  //             <tr {...headerGroup.getHeaderGroupProps()}>
  //               {headerGroup.headers.map((column) => (
  //                 <th {...column.getHeaderProps()}>
  //                   {column.render("Header")}
  //                 </th>
  //               ))}
  //             </tr>
  //           ))}
  //         </thead>
  //         <tbody {...getTableBodyProps()}>
  //           {rows.map((row) => {
  //             prepareRow(row);
  //             return (
  //               <tr {...row.getRowProps()}>
  //                 {row.cells.map((cell) => (
  //                 <td {...cell.getCellProps()}> {cell.render("Cell")} </td>
  //                 ))}
  //               </tr>
  //             );
  //           })}
  //         </tbody>
  //       </table>
  //     </div>
  //   </div>
  // );
  // <table className="table">
  //     <thead>
  //       <tr>
  //         <th>
  //           <input
  //             type="checkbox"
  //             onChange={(event) => {
  //               const checked = event.target.checked;
  //               const newCheckboxValues = data.map((item) => checked ? item.id : null);
  //               setCheckboxValues(newCheckboxValues);
  //             }}
  //           />
  //         </th>
  //         <td class="adc">SI No</td>
  //         <td>CUSTOMER ORDER ID</td>
  //         <td>SALES ORG</td>
  //         <td>DISTRIBTUION CHANNEL</td>
  //         <td>COMPANY CODE</td>
  //           <td>ORDER CREATION DATE</td>
  //           <td>ORDER AMOUNT</td>
  //           <td>ORDER CURRENCY</td>
  //           <td>CUSTOMER NUMBER</td>
  //           <td>AMOUNT IN USD</td>
  //         {/* Add more table headers as needed */}
  //       </tr>
  //     </thead>
  //     <tbody>
  //       {data.map((item) => (
  //         <tr key={item.id}>
  //           <td>
  //             <input
  //               type="checkbox"
  //               checked={checkboxValues.includes(item.id)}
  //               onChange={(event) => {
  //                 const checked = event.target.checked;
  //                 let newCheckboxValues = [...checkboxValues];
  //                 if (checked) {
  //                   newCheckboxValues.push(item.id);
  //                 } else {
  //                   newCheckboxValues = newCheckboxValues.filter((value) => value !== item.id);
  //                 }
  //                 setCheckboxValues(newCheckboxValues);
  //               }}
  //             />
  //           </td>
  //           <td>{item.column1}</td>
  //           <td>{item.column2}</td>
  //           {/* Add more table cells as needed */}
  //         </tr>
  //       ))}
  //     </tbody>
  //   </table>
  // );
  return(
  <div className="Table"> 
    <Table/>
  </div>
  );
}

export default App;
